
Sitio estático para "Distri Alvear - Bebidas y Alimentos"

Archivos incluidos:
- index.html
- style.css
- script.js
- carpeta 'imagenes' con logo y 5 imágenes de ejemplo.

Pasos rápidos para publicar en GitHub Pages:
1. Crea una cuenta en https://github.com si no tenés.
2. Crea un nuevo repositorio (por ejemplo: distri-alvear).
3. Sube todos los archivos y carpetas al repositorio.
4. En el repositorio, andá a Settings → Pages → Y seleccioná la rama 'main' (o 'master') y la carpeta '/ (root)'.
5. Guardá; en unos segundos/minutos la web estará disponible en:
   https://TUUSUARIO.github.io/distri-alvear

Nota:
- Reemplazá precios, textos y la dirección por la información exacta.
- Si querés más productos o integración con pagos, avisame y lo agrego.
